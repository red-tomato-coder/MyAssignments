g++ -std=c++17 -o ./main main.cpp $(pkg-config --cflags --libs gtkmm-4.0)
